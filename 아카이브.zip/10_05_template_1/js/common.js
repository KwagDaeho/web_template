// Made By Haraho:곽대호
$(function () {
  $(".modal_btn").click(function () {
    $(".modal_window").fadeToggle();
  });
});
