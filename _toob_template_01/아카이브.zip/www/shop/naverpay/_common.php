<?php
define('_SHOP_', true);
include_once('../../common.php');