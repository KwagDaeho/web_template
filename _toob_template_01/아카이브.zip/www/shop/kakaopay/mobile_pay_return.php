<?php
include_once('./_common.php');

// 카카오페이 (KG 이니시스) 의 경우 NOTI 과정이 없으므로 이 페이지를 사용하지 않습니다.