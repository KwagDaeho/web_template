// Made By Haraho:곽대호
$(function () {
  $(".modal_btn").click(function () {
    $(".modal_window").fadeToggle();
  });
  // $(".tp_modal_gnb li").click(function () {
  //   $(this).children("ol").slideToggle();
  // });
});
