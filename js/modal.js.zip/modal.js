/*
1. 대화상자를 여는 버튼에는 aria-haspopup="dialog" 속성과 aria-controls 속성을 줍니다. aria-controls 에는 버튼과 연결된 role="dialog" 요소의 id 를 주면 됩니다.
예: <button aria-haspopup="dialog" aria-controls="dialog-container">대화상자 열기</button>
2. role="dialog" 속성은 대화상자가 있는 컨테이너에 주되 <body> 요소 바로 아래에 있는 객체여야 합니다. 이는 대화상자가 display:block 되었을 때 해당 요소를 제외한 모든 형재는 aria-hidden="true" 속성이 붙기 때문입니다.
3. aria-haspopup="dialog" 를 클릭하여 대화상자가 열렸을 때 초점을 대화상자 내부의 특정 요소로 보내려면 해당 요소에 autoFocus 라는 class 를 주면 됩니다. 다만 반드시 해당 요소에는 tabindex="0" 혹은 "-1" 속성이 들어가 있어야 합니다.
4. 대화상자 내부에서 포커스 트랩을 구현하기 위해 class="firstTab" class="lastTab" 클래스를 각각 지정합니다. 이렇게 하면 firstTab 요소에서 쉬프트 탭을 누르면 lastTab class 로, lastTab class 에서 탭키를 누르면 firstTab class 로 이동합니다.
5. 마지막으로 대화상자를 닫는 버튼에는 class="modalClose" 를 추가합니다. 그러면 취소 키를 눌렀을 때 해당 요소가 클릭되면서 대화상자가 사라지고 초점은 이전 대화상자를 여는 버튼으로 돌아가게 됩니다. 대화상자가 display:none 되면 모든 aria-hidden 속성은 사라집니다.
*/
"use strict";

// 오토포커스 추가부분
document.addEventListener("DOMContentLoaded", function (e) {
  for (var i = 0; i < $modal.length; i++) {
    if ($modal[i].classList.contains("autoFocus")) {
      $modal[i].focus();
    }
  }
});
// 오토포커스 추가부분 끝

var $body = document.querySelector("body"),
  $targetAreas = $body.querySelectorAll("[aria-haspopup=dialog]"),
  modals = $body.querySelectorAll("[role=dialog]"),
  $modal = null,
  $firstTab,
  $lastTab,
  $closeModal,
  $targetArea;

$targetAreas.forEach(function ($el) {
  $el.addEventListener("click", initialize, false);
});

function initialize(event) {
  $targetArea = event.target;

  modals.forEach(function ($el) {
    if (
      $targetArea.getAttribute("aria-controls") &&
      $targetArea.getAttribute("aria-controls") == $el.getAttribute("id") &&
      "true" == $el.getAttribute("aria-modal") &&
      window.getComputedStyle($el).display === "block"
    ) {
      $modal = $el;
      setInertness($modal);
    }
  });

  if ($modal) {
    ($closeModal = $modal.querySelector(".closeModal")),
      ($firstTab = $modal.querySelector(".firstTab")),
      ($lastTab = $modal.querySelector(".lastTab"));

    $modal.addEventListener("keydown", bindKeyEvt);
    $modal.addEventListener("click", function (event) {
      if (window.getComputedStyle($modal).display === "none") {
        unsetInertness();
        $modal.removeEventListener("keydown", bindKeyEvt, false);
        $targetArea.focus();
        ($modal = null),
          ($firstTab = null),
          ($lastTab = null),
          ($closeModal = null),
          ($targetArea = null);
      }
    });

    if ($firstTab) $firstTab.focus();
  }
}

function setInertness(dialog) {
  var ommits = ["script", "meta", "link", "style", "base"];
  for (var i = -1, node; (node = dialog.parentNode.children[++i]); ) {
    if (node == dialog || ommits.indexOf(node.tagName.toLowerCase()) > -1)
      continue;
    node.setAttribute("aria-hidden", "true");
    node.setAttribute("inert", "");
  }
}

function unsetInertness() {
  var nodes = document.querySelectorAll("[inert]");
  for (var i = -1, node = null; (node = nodes[++i]); ) {
    node.removeAttribute("aria-hidden");
    node.removeAttribute("inert");
  }
}

function bindKeyEvt(event) {
  event = event || window.event;
  var keycode = event.keycode || event.which;
  var $target = event.target;

  switch (keycode) {
    case 9: // tab key
      if ($firstTab && $lastTab) {
        if (event.shiftKey) {
          if ($firstTab && $target == $firstTab) {
            event.preventDefault();
            if ($lastTab) $lastTab.focus();
          }
        } else {
          if ($lastTab && $target == $lastTab) {
            event.preventDefault();
            if ($firstTab) $firstTab.focus();
          }
        }
      } else {
        event.preventDefault();
      }
      break;
    case 27: // esc key
      event.preventDefault();
      $closeModal.click();
      break;
    default:
      break;
  }
}
